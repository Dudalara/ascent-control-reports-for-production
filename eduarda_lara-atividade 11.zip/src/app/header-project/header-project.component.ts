import { Component } from '@angular/core';

@Component({
  selector: 'app-header-project',
  templateUrl: './header-project.component.html',
  styleUrls: ['./header-project.component.css']
})
export class HeaderProjectComponent {
 logoPath = 'assets/resources/images/logo.jpg';
}
