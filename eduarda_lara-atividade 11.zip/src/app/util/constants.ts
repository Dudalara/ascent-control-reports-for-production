export class Constants {
    public static readonly REPORTS_KEY = 'reports';
  }