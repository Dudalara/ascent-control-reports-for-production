import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-project',
  templateUrl: './footer-project.component.html',
  styleUrls: ['./footer-project.component.css']
})
export class FooterProjectComponent {
  footerPhase = '© 2023 Copyright';

}
