export class Instance {
  public id: number;
  public name: string;
}