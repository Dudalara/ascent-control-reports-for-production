
export class Report {
  instanceName: string;
  updatedSet: string;
  author: string;
  updateDate: Date;
  createdComponent: String;
  comments?: string;
  id: number;
}